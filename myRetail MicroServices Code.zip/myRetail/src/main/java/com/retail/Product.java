package com.retail;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
	"Id","name","current_price"
})
public class Product {
	private int Id;
	private String name;
	private current_price current_price;
	
	public Product() {
			}
	public Product(int id, String name, com.retail.current_price current_price) {
		super();
		Id = id;
		this.name = name;
		this.current_price = current_price;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public current_price getCurrent_price() {
		return current_price;
	}
	public void setCurrent_price(current_price current_price) {
		this.current_price = current_price;
	}
	
	}
class current_price{
	private double value;
	private String currency_code;
	public current_price(double value, String currency_code) {
		super();
		this.value = value;
		this.currency_code = currency_code;
	}
	public double getValue() {
		return value;
	}
	public void setValue(double value) {
		this.value = value;
	}
	public String getCurrency_code() {
		return currency_code;
	}
	public void setCurrency_code(String currency_code) {
		this.currency_code = currency_code;
	}
			
}