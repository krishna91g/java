package com.retail;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(JUnit4.class)
@SpringBootTest
public class SpringBootMockitoApplicationTest {
	@Autowired
	@MockBean
	private ProductService myService;
	
	@Test
	public void getProductsTest() {
		when(myService.getAllProducts()).thenReturn(
				Stream.of(new Product(1,"Product-1",new current_price(11.11,"USD")),
						new Product(2,"Product-2",new current_price(22.22,"USD")))
				.collect(Collectors.toList()));
		assertEquals(2, myService.getAllProducts().size());
	}
}
