package com.retail.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class MyExceptionHandler extends ResponseEntityExceptionHandler {
	@ExceptionHandler(CustomException.class)
	public ResponseEntity<ErrorMessage> myMessage(CustomException ex){
		ErrorMessage exceptionResponse = new ErrorMessage(ex.getMessage(), "Something went wrong");
		return new ResponseEntity<ErrorMessage>(exceptionResponse, new HttpHeaders(),HttpStatus.INTERNAL_SERVER_ERROR);
	}
}

class ErrorMessage{
	private String Message;
	private String Details;
	
	public ErrorMessage(String message, String details) {
		super();
		this.Message = message;
		this.Details = details;
	}
	public String getMessage() {
		return Message;
	}
	public void setMessage(String message) {
		this.Message = message;
	}
	public String getDetails() {
		return Details;
	}
	public void setDetails(String details) {
		this.Details = details;
	}
	
	
}
