package com.retail.exception;

public class CustomException extends Throwable {

	private static final long serialVersionUID = 4446739239288723966L;

	public CustomException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
