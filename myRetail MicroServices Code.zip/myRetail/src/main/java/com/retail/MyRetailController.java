package com.retail;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.retail.exception.CustomException;

@RestController
public class MyRetailController {
	@Autowired
	private ProductService productService;

	
	/********************* API to display all Products **************************/

	@RequestMapping(value = "/products", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Product> getAllProducts() {
		return productService.getAllProducts();
	}

	/********************* API to display Products by Id **************************/

	@SuppressWarnings("finally")
	@RequestMapping(value = "/product/{Id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Product getProductById(@PathVariable int Id) throws Throwable {
		System.out.println("inside method");
		Product prd = null;

		try {
			prd = productService.getProductById(Id);
		} catch (RuntimeException ex) {
			throw new CustomException(ex.getMessage());
		} finally {
			if (prd == null) {
				throw new CustomException("No products available for the product Id::" + Id);
			} else {
				return prd;
			}
		}

	}

	/********************* * * API to display Products by Name	 **************************/

	@SuppressWarnings("finally")
	@RequestMapping(value = "/products/{Name}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Product getProductByName(@PathVariable String Name) throws Throwable {
		Product prd = null;

		try {
			prd = productService.getProductByName(Name);
		} catch (RuntimeException ex) {
			throw new CustomException(ex.getMessage());
		} finally {
			if (prd == null) {
				throw new CustomException("No products available for the product Name::" + Name);
			} else {
				return prd;
			}
		}

	}

	/********************* * * API to test error handling	 **************************/
	
	@RequestMapping(value = "/errortest")
	public void test() throws CustomException {
		throw new CustomException("Failed");
	}
}