package com.retail;

import java.util.Arrays;
import java.util.List;
import org.springframework.stereotype.Service;
import com.retail.exception.CustomException;

@Service
public class ProductService {
	
	private List<Product> product = Arrays.asList(
			new Product(1,"Product-1",new current_price(11.11,"USD")),
			new Product(2,"Product-2",new current_price(22.22,"USD")),
			new Product(3,"Product-3",new current_price(33.33,"USD")),
			new Product(4,"Product-4",new current_price(44.44,"USD"))				
			);	

	public List<Product> getAllProducts(){
		return product;
	}
	
	public Product getProductById(int Id) throws CustomException  {
		Product prdById = new Product();
		prdById = product.stream().filter(t->t.getId()==Id).findFirst().get();
		return prdById;
	}
	public Product getProductByName(String name) throws CustomException  {
		Product prdByName = new Product();
		prdByName = product.stream().filter(t->t.getName().equals(name)).findFirst().get();
		return prdByName;
	}
	public void addTopic(Product prd) {
		product.add(prd);		
	}
	public void updateTopic(Product prd, int Id) {
		for(int i=0;i<product.size();i++){
			Product tp = product.get(i);
				if(tp.getId()==Id) {
					product.set(i, prd);
					return;}				
			}
		}

}
